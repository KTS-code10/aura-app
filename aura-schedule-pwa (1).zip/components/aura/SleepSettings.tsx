'use client'

import { Moon, Sunrise } from 'lucide-react'
import { SleepConfig } from '@/lib/types'

interface SleepSettingsProps {
  config: SleepConfig
  onChange: (config: SleepConfig) => void
}

export function SleepSettings({ config, onChange }: SleepSettingsProps) {
  return (
    <div className="flex flex-col gap-3">
      <h2 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
        Cycle de sommeil
      </h2>
      <div className="grid grid-cols-2 gap-2">
        <div className="flex flex-col gap-1.5 bg-muted/40 border border-border/50 rounded-xl p-3">
          <div className="flex items-center gap-1.5 text-muted-foreground">
            <Moon size={13} />
            <span className="text-[10px] uppercase tracking-wider">Coucher</span>
          </div>
          <input
            type="time"
            value={config.bedtime}
            onChange={(e) => onChange({ ...config, bedtime: e.target.value })}
            className="bg-transparent text-foreground text-sm font-semibold focus:outline-none focus:ring-1 focus:ring-primary rounded w-full"
            aria-label="Heure de coucher"
          />
        </div>
        <div className="flex flex-col gap-1.5 bg-muted/40 border border-border/50 rounded-xl p-3">
          <div className="flex items-center gap-1.5 text-muted-foreground">
            <Sunrise size={13} />
            <span className="text-[10px] uppercase tracking-wider">Lever</span>
          </div>
          <input
            type="time"
            value={config.wakeup}
            onChange={(e) => onChange({ ...config, wakeup: e.target.value })}
            className="bg-transparent text-foreground text-sm font-semibold focus:outline-none focus:ring-1 focus:ring-primary rounded w-full"
            aria-label="Heure de lever"
          />
        </div>
      </div>
      <div className="flex items-center justify-between text-xs text-muted-foreground bg-muted/30 rounded-lg px-3 py-2">
        <span>Durée de sommeil</span>
        <span className="font-semibold text-foreground">
          {(() => {
            const bed = config.bedtime.split(':').map(Number)
            const wake = config.wakeup.split(':').map(Number)
            const bedMin = bed[0] * 60 + bed[1]
            const wakeMin = wake[0] * 60 + wake[1]
            const diff = wakeMin <= bedMin ? (24 * 60 - bedMin + wakeMin) : (wakeMin - bedMin)
            const h = Math.floor(diff / 60)
            const m = diff % 60
            return `${h}h${m > 0 ? m + 'min' : ''}`
          })()}
        </span>
      </div>
    </div>
  )
}
