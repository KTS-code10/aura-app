'use client'

import { useState, useEffect } from 'react'
import { X, Trash2, CheckCircle2 } from 'lucide-react'
import { CalendarBlock } from '@/lib/types'
import { cn } from '@/lib/utils'

interface EditBlockModalProps {
  block: CalendarBlock | null
  onClose: () => void
  onSave: (block: CalendarBlock) => void
  onDelete: (id: string) => void
}

const TYPE_LABELS: Record<string, string> = {
  fixe: 'Événement Fixe',
  fluide: 'Tâche Fluide',
  habit: 'Habitude',
  sommeil: 'Sommeil',
  tampon: 'Pause / Tampon',
}

export function EditBlockModal({ block, onClose, onSave, onDelete }: EditBlockModalProps) {
  const [title, setTitle] = useState('')
  const [startTime, setStartTime] = useState('')
  const [endTime, setEndTime] = useState('')
  const [completed, setCompleted] = useState(false)

  useEffect(() => {
    if (block) {
      setTitle(block.title)
      setStartTime(block.startTime)
      setEndTime(block.endTime === '24:00' ? '24:00' : block.endTime)
      setCompleted(block.completed)
    }
  }, [block])

  if (!block) return null

  const handleSave = () => {
    onSave({
      ...block,
      title,
      startTime,
      endTime,
      completed,
    })
    onClose()
  }

  const isSleepOrBuffer = block.type === 'sommeil' || block.type === 'tampon'

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm p-4"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="bg-card border border-border rounded-2xl w-full max-w-sm shadow-2xl flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-5 pt-5 pb-3 border-b border-border">
          <div className="flex items-center gap-2">
            <div
              className="w-3 h-3 rounded-full shrink-0"
              style={{ backgroundColor: block.color }}
            />
            <span className="text-xs text-muted-foreground uppercase tracking-wider">
              {TYPE_LABELS[block.type] || block.type}
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-muted transition-colors text-muted-foreground"
            aria-label="Fermer"
          >
            <X size={15} />
          </button>
        </div>

        {/* Body */}
        <div className="px-5 py-4 flex flex-col gap-4">
          {/* Title */}
          <div className="flex flex-col gap-1.5">
            <label className="text-[10px] uppercase tracking-wider text-muted-foreground">
              Titre
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              disabled={isSleepOrBuffer}
              className="w-full bg-muted text-foreground text-sm rounded-lg px-3 py-2.5 border border-border focus:outline-none focus:ring-1 focus:ring-primary disabled:opacity-50 disabled:cursor-not-allowed"
            />
          </div>

          {/* Time range */}
          <div className="grid grid-cols-2 gap-2">
            <div className="flex flex-col gap-1.5">
              <label className="text-[10px] uppercase tracking-wider text-muted-foreground">
                Début
              </label>
              <input
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                disabled={isSleepOrBuffer}
                className="w-full bg-muted text-foreground text-sm rounded-lg px-3 py-2.5 border border-border focus:outline-none focus:ring-1 focus:ring-primary disabled:opacity-50 disabled:cursor-not-allowed"
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <label className="text-[10px] uppercase tracking-wider text-muted-foreground">
                Fin
              </label>
              <input
                type="time"
                value={endTime === '24:00' ? '00:00' : endTime}
                onChange={(e) => setEndTime(e.target.value)}
                disabled={isSleepOrBuffer}
                className="w-full bg-muted text-foreground text-sm rounded-lg px-3 py-2.5 border border-border focus:outline-none focus:ring-1 focus:ring-primary disabled:opacity-50 disabled:cursor-not-allowed"
              />
            </div>
          </div>

          {/* Completed toggle */}
          {!isSleepOrBuffer && (
            <button
              onClick={() => setCompleted(!completed)}
              className={cn(
                'flex items-center gap-2 rounded-xl px-3 py-2.5 border transition-colors',
                completed
                  ? 'bg-primary/10 border-primary/50 text-primary'
                  : 'bg-muted border-border text-muted-foreground hover:border-primary/30'
              )}
            >
              {completed ? <CheckCircle2 size={15} /> : <div className="w-[15px] h-[15px] rounded-full border-2 border-current" />}
              <span className="text-sm font-medium">
                {completed ? 'Tâche terminée' : 'Marquer comme terminée'}
              </span>
            </button>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 pb-5 flex gap-2">
          {!isSleepOrBuffer && (
            <button
              onClick={() => { onDelete(block.id); onClose() }}
              className="p-2.5 rounded-xl bg-muted hover:bg-[#ef6c6c]/20 border border-border hover:border-[#ef6c6c]/50 text-muted-foreground hover:text-[#ef6c6c] transition-colors"
              aria-label="Supprimer"
            >
              <Trash2 size={15} />
            </button>
          )}
          <button
            onClick={onClose}
            className="flex-1 py-2.5 rounded-xl bg-muted hover:bg-secondary text-foreground text-sm font-medium border border-border transition-colors"
          >
            Annuler
          </button>
          {!isSleepOrBuffer && (
            <button
              onClick={handleSave}
              className="flex-1 py-2.5 rounded-xl bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 transition-opacity"
            >
              Enregistrer
            </button>
          )}
        </div>
      </div>
    </div>
  )
}
