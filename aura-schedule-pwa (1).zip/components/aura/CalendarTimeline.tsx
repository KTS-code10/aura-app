'use client'

import { useEffect, useRef, useState } from 'react'
import { CheckCircle2, Circle, Pencil, Trash2 } from 'lucide-react'
import { CalendarBlock } from '@/lib/types'
import { timeToMinutes } from '@/lib/store'
import { cn } from '@/lib/utils'

interface CalendarTimelineProps {
  blocks: CalendarBlock[]
  onEditBlock: (block: CalendarBlock) => void
  onDeleteBlock: (id: string) => void
  onToggleBlock: (id: string) => void
  selectedDate?: string
}

const HOUR_HEIGHT = 64 // px per hour
const DAY_START = 0    // 00:00
const DAY_END = 24     // 24:00
const TOTAL_HOURS = DAY_END - DAY_START

function minutesSinceDayStart(time: string): number {
  if (time === '24:00') return 24 * 60
  return timeToMinutes(time)
}

export function CalendarTimeline({
  blocks,
  onEditBlock,
  onDeleteBlock,
  onToggleBlock,
  selectedDate,
}: CalendarTimelineProps) {
  const containerRef = useRef<HTMLDivElement>(null)
  const [nowMinutes, setNowMinutes] = useState(0)
  const [hoveredId, setHoveredId] = useState<string | null>(null)

  useEffect(() => {
    const update = () => {
      const now = new Date()
      setNowMinutes(now.getHours() * 60 + now.getMinutes())
    }
    update()
    const interval = setInterval(update, 60000)
    return () => clearInterval(interval)
  }, [])

  // Scroll to current time on mount
  useEffect(() => {
    if (containerRef.current) {
      const scrollTarget = ((nowMinutes - 60) / 60) * HOUR_HEIGHT
      containerRef.current.scrollTop = Math.max(0, scrollTarget)
    }
  }, [nowMinutes])

  const hours = Array.from({ length: TOTAL_HOURS + 1 }, (_, i) => i)

  const getBlockStyle = (block: CalendarBlock) => {
    const startMin = minutesSinceDayStart(block.startTime)
    const endMin = minutesSinceDayStart(block.endTime)
    const top = (startMin / 60) * HOUR_HEIGHT
    const height = Math.max(((endMin - startMin) / 60) * HOUR_HEIGHT, 18)
    return { top, height }
  }

  const isSmallBlock = (block: CalendarBlock) => {
    const startMin = minutesSinceDayStart(block.startTime)
    const endMin = minutesSinceDayStart(block.endTime)
    return endMin - startMin <= 20
  }

  const isTinyBlock = (block: CalendarBlock) => {
    const startMin = minutesSinceDayStart(block.startTime)
    const endMin = minutesSinceDayStart(block.endTime)
    return endMin - startMin < 15
  }

  const nowTop = (nowMinutes / 60) * HOUR_HEIGHT

  // Sort blocks: sleep blocks first (as background), then others
  const sleepBlocks = blocks.filter((b) => b.type === 'sommeil')
  const otherBlocks = blocks.filter((b) => b.type !== 'sommeil')

  return (
    <div ref={containerRef} className="flex-1 overflow-y-auto relative">
      <div
        className="relative"
        style={{ height: `${TOTAL_HOURS * HOUR_HEIGHT}px` }}
      >
        {/* Hour lines */}
        {hours.map((hour) => (
          <div
            key={hour}
            className="absolute left-0 right-0 flex items-start pointer-events-none"
            style={{ top: `${hour * HOUR_HEIGHT}px` }}
          >
            <div className="w-14 shrink-0 text-right pr-3 pt-0.5">
              {hour < 24 && (
                <span className="text-[10px] text-muted-foreground font-mono">
                  {String(hour).padStart(2, '0')}:00
                </span>
              )}
            </div>
            <div className="flex-1 border-t border-border/30" />
          </div>
        ))}

        {/* 15-min sub-lines */}
        {hours.slice(0, -1).map((hour) =>
          [15, 30, 45].map((min) => (
            <div
              key={`${hour}-${min}`}
              className="absolute left-14 right-0 border-t border-border/10 pointer-events-none"
              style={{ top: `${hour * HOUR_HEIGHT + (min / 60) * HOUR_HEIGHT}px` }}
            />
          ))
        )}

        {/* Sleep blocks (background) */}
        {sleepBlocks.map((block) => {
          const { top, height } = getBlockStyle(block)
          return (
            <div
              key={block.id}
              className="absolute left-14 right-2 rounded-none opacity-90 pointer-events-none"
              style={{
                top: `${top}px`,
                height: `${height}px`,
                backgroundColor: block.color,
              }}
              aria-hidden="true"
            >
              {height > 40 && (
                <div className="flex items-center gap-1 px-3 pt-2">
                  <span className="text-xs text-muted-foreground/60">Sommeil</span>
                </div>
              )}
            </div>
          )
        })}

        {/* Task blocks */}
        {otherBlocks.map((block) => {
          const { top, height } = getBlockStyle(block)
          const small = isSmallBlock(block)
          const tiny = isTinyBlock(block)
          const isHovered = hoveredId === block.id
          const isBuffer = block.type === 'tampon'

          if (isBuffer) {
            return (
              <div
                key={block.id}
                className="absolute left-14 right-2 rounded-md pointer-events-none"
                style={{
                  top: `${top}px`,
                  height: `${height}px`,
                  backgroundColor: block.color,
                  opacity: 0.5,
                }}
                aria-hidden="true"
              />
            )
          }

          return (
            <div
              key={block.id}
              className={cn(
                'absolute left-14 right-2 rounded-xl border border-white/5 cursor-pointer transition-all duration-150 group',
                block.completed ? 'opacity-50' : 'opacity-100',
                isHovered ? 'ring-1 ring-white/30 z-20' : 'z-10'
              )}
              style={{
                top: `${top}px`,
                height: `${height}px`,
                backgroundColor: `${block.color}22`,
                borderLeft: `3px solid ${block.color}`,
              }}
              onMouseEnter={() => setHoveredId(block.id)}
              onMouseLeave={() => setHoveredId(null)}
              onClick={() => !small && onEditBlock(block)}
              role="button"
              tabIndex={0}
              onKeyDown={(e) => e.key === 'Enter' && onEditBlock(block)}
              aria-label={`${block.title} ${block.startTime}–${block.endTime}`}
            >
              {/* Block content */}
              <div className="flex items-start justify-between h-full px-2.5 py-1.5 overflow-hidden">
                <div className="flex-1 min-w-0 flex flex-col justify-center gap-0.5">
                  {!tiny && (
                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={(e) => {
                          e.stopPropagation()
                          onToggleBlock(block.id)
                        }}
                        className="shrink-0"
                        aria-label={block.completed ? 'Marquer non terminé' : 'Marquer terminé'}
                      >
                        {block.completed ? (
                          <CheckCircle2 size={12} style={{ color: block.color }} />
                        ) : (
                          <Circle size={12} style={{ color: block.color }} />
                        )}
                      </button>
                      <span
                        className={cn(
                          'text-xs font-medium leading-tight truncate',
                          block.completed ? 'line-through text-muted-foreground' : 'text-foreground'
                        )}
                        style={{ color: block.completed ? undefined : block.color }}
                      >
                        {block.title}
                      </span>
                    </div>
                  )}
                  {!small && (
                    <span className="text-[10px] text-muted-foreground ml-5">
                      {block.startTime} – {block.endTime}
                    </span>
                  )}
                </div>

                {/* Action buttons on hover */}
                {!small && isHovered && (
                  <div className="flex items-center gap-1 shrink-0 ml-1">
                    <button
                      onClick={(e) => {
                        e.stopPropagation()
                        onEditBlock(block)
                      }}
                      className="p-1 rounded bg-white/10 hover:bg-white/20 transition-colors text-muted-foreground hover:text-foreground"
                      aria-label="Modifier le bloc"
                    >
                      <Pencil size={10} />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation()
                        onDeleteBlock(block.id)
                      }}
                      className="p-1 rounded bg-white/10 hover:bg-red-500/30 transition-colors text-muted-foreground hover:text-[#ef6c6c]"
                      aria-label="Supprimer le bloc"
                    >
                      <Trash2 size={10} />
                    </button>
                  </div>
                )}
              </div>
            </div>
          )
        })}

        {/* Current time indicator */}
        <div
          className="absolute left-0 right-0 z-30 pointer-events-none flex items-center"
          style={{ top: `${nowTop}px` }}
        >
          <div className="w-14 flex justify-end pr-1.5">
            <div className="w-2 h-2 rounded-full bg-primary shrink-0" />
          </div>
          <div className="flex-1 h-[1.5px] bg-primary" />
        </div>
      </div>
    </div>
  )
}
