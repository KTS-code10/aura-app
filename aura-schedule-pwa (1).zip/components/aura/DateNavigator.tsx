'use client'

import { useState } from 'react'
import { ChevronLeft, ChevronRight, CalendarDays, Calendar as CalendarIcon } from 'lucide-react'
import {
  formatDateLabel,
  formatShortDateLabel,
  addDays,
  getWeekDays,
  parseDateKey,
  getToday,
  isToday,
  JOURS_FR,
  MOIS_FR,
} from '@/lib/store'
import { cn } from '@/lib/utils'

interface DateNavigatorProps {
  selectedDate: string
  onDateChange: (date: string) => void
  dayDataByDate: Record<string, { blocks: unknown[] }>
}

export function DateNavigator({ selectedDate, onDateChange, dayDataByDate }: DateNavigatorProps) {
  const [showMiniCal, setShowMiniCal] = useState(false)
  const [miniCalMonth, setMiniCalMonth] = useState(() => {
    const d = parseDateKey(selectedDate)
    return { year: d.getFullYear(), month: d.getMonth() }
  })

  const weekDays = getWeekDays(selectedDate)
  const today = getToday()

  const goToPrevDay = () => onDateChange(addDays(selectedDate, -1))
  const goToNextDay = () => onDateChange(addDays(selectedDate, 1))
  const goToToday = () => onDateChange(today)

  // Mini calendar helpers
  const getDaysInMonth = (year: number, month: number) => {
    const firstDay = new Date(year, month, 1)
    const lastDay = new Date(year, month + 1, 0)
    const startDayOfWeek = (firstDay.getDay() + 6) % 7 // Monday = 0
    
    const days: (string | null)[] = []
    for (let i = 0; i < startDayOfWeek; i++) days.push(null)
    for (let i = 1; i <= lastDay.getDate(); i++) {
      const d = new Date(year, month, i)
      days.push(d.toISOString().split('T')[0])
    }
    return days
  }

  const miniCalDays = getDaysInMonth(miniCalMonth.year, miniCalMonth.month)

  const prevMonth = () => {
    setMiniCalMonth((prev) => {
      if (prev.month === 0) return { year: prev.year - 1, month: 11 }
      return { ...prev, month: prev.month - 1 }
    })
  }

  const nextMonth = () => {
    setMiniCalMonth((prev) => {
      if (prev.month === 11) return { year: prev.year + 1, month: 0 }
      return { ...prev, month: prev.month + 1 }
    })
  }

  const hasDataForDate = (dateKey: string | null) => {
    if (!dateKey) return false
    return dayDataByDate[dateKey]?.blocks?.length > 0
  }

  return (
    <div className="flex flex-col gap-2">
      {/* Main date header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <button
            onClick={goToPrevDay}
            className="p-1.5 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
            aria-label="Jour précédent"
          >
            <ChevronLeft size={16} />
          </button>
          
          <button
            onClick={() => setShowMiniCal(!showMiniCal)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg hover:bg-muted transition-colors"
          >
            <CalendarIcon size={14} className="text-primary" />
            <span className="text-sm font-medium text-foreground capitalize">
              {formatDateLabel(selectedDate)}
            </span>
          </button>
          
          <button
            onClick={goToNextDay}
            className="p-1.5 rounded-lg hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
            aria-label="Jour suivant"
          >
            <ChevronRight size={16} />
          </button>
        </div>

        {!isToday(selectedDate) && (
          <button
            onClick={goToToday}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg bg-primary/10 text-primary hover:bg-primary/20 transition-colors"
          >
            <CalendarDays size={12} />
            Aujourd&apos;hui
          </button>
        )}
      </div>

      {/* Week strip */}
      <div className="flex gap-1 py-1">
        {weekDays.map((day) => {
          const d = parseDateKey(day)
          const dayNum = d.getDate()
          const dayName = JOURS_FR[d.getDay()]
          const isSelected = day === selectedDate
          const isTodayDate = day === today
          const hasData = hasDataForDate(day)

          return (
            <button
              key={day}
              onClick={() => onDateChange(day)}
              className={cn(
                'flex-1 flex flex-col items-center py-2 px-1 rounded-lg transition-all',
                isSelected
                  ? 'bg-primary text-primary-foreground'
                  : isTodayDate
                    ? 'bg-primary/20 text-primary hover:bg-primary/30'
                    : 'hover:bg-muted text-muted-foreground hover:text-foreground'
              )}
            >
              <span className="text-[10px] uppercase">{dayName}</span>
              <span className="text-sm font-semibold">{dayNum}</span>
              {hasData && !isSelected && (
                <div className="w-1 h-1 rounded-full bg-primary mt-0.5" />
              )}
            </button>
          )
        })}
      </div>

      {/* Mini calendar dropdown */}
      {showMiniCal && (
        <div className="absolute top-full left-0 mt-2 z-50 bg-card border border-border rounded-xl shadow-2xl p-4 w-72">
          {/* Month navigation */}
          <div className="flex items-center justify-between mb-3">
            <button
              onClick={prevMonth}
              className="p-1 rounded hover:bg-muted transition-colors text-muted-foreground"
            >
              <ChevronLeft size={16} />
            </button>
            <span className="text-sm font-medium text-foreground capitalize">
              {MOIS_FR[miniCalMonth.month]} {miniCalMonth.year}
            </span>
            <button
              onClick={nextMonth}
              className="p-1 rounded hover:bg-muted transition-colors text-muted-foreground"
            >
              <ChevronRight size={16} />
            </button>
          </div>

          {/* Day headers */}
          <div className="grid grid-cols-7 gap-1 mb-1">
            {['L', 'M', 'M', 'J', 'V', 'S', 'D'].map((d, i) => (
              <div key={i} className="text-center text-[10px] text-muted-foreground py-1">
                {d}
              </div>
            ))}
          </div>

          {/* Calendar grid */}
          <div className="grid grid-cols-7 gap-1">
            {miniCalDays.map((day, i) => {
              if (!day) {
                return <div key={`empty-${i}`} className="w-8 h-8" />
              }

              const d = parseDateKey(day)
              const isSelected = day === selectedDate
              const isTodayDate = day === today
              const hasData = hasDataForDate(day)

              return (
                <button
                  key={day}
                  onClick={() => {
                    onDateChange(day)
                    setShowMiniCal(false)
                  }}
                  className={cn(
                    'w-8 h-8 rounded-lg text-xs font-medium transition-all relative',
                    isSelected
                      ? 'bg-primary text-primary-foreground'
                      : isTodayDate
                        ? 'bg-primary/20 text-primary'
                        : 'hover:bg-muted text-foreground'
                  )}
                >
                  {d.getDate()}
                  {hasData && !isSelected && (
                    <div className="absolute bottom-1 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-primary" />
                  )}
                </button>
              )
            })}
          </div>

          {/* Quick actions */}
          <div className="flex gap-2 mt-3 pt-3 border-t border-border">
            <button
              onClick={() => {
                onDateChange(today)
                setShowMiniCal(false)
              }}
              className="flex-1 py-1.5 text-xs font-medium rounded-lg bg-primary/10 text-primary hover:bg-primary/20 transition-colors"
            >
              Aujourd&apos;hui
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
