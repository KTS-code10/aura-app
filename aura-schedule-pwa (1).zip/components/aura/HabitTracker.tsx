'use client'

import { useState } from 'react'
import { CheckCircle2, Circle, BookOpen, Dumbbell, Plus, Trash2 } from 'lucide-react'
import { Habit } from '@/lib/types'
import { cn } from '@/lib/utils'

interface HabitTrackerProps {
  habits: Habit[]
  onToggleHabit: (id: string) => void
  onAddHabit: (habit: Omit<Habit, 'id' | 'completedToday'>) => void
  onDeleteHabit: (id: string) => void
}

const HABIT_ICONS: Record<string, React.ReactNode> = {
  BookOpen: <BookOpen size={14} />,
  Dumbbell: <Dumbbell size={14} />,
}

const PRESET_COLORS = ['#4ecdc4', '#f5a623', '#7c6cf5', '#ef6c6c', '#45b7d1']

export function HabitTracker({ habits, onToggleHabit, onAddHabit, onDeleteHabit }: HabitTrackerProps) {
  const [showForm, setShowForm] = useState(false)
  const [newTitle, setNewTitle] = useState('')
  const [newDuration, setNewDuration] = useState(30)
  const [newFrequency, setNewFrequency] = useState('Quotidien')
  const [newColor, setNewColor] = useState(PRESET_COLORS[0])
  const [newIcon, setNewIcon] = useState('BookOpen')

  const handleAdd = () => {
    if (!newTitle.trim()) return
    onAddHabit({
      title: newTitle.trim(),
      duration: newDuration,
      frequency: newFrequency,
      color: newColor,
      icon: newIcon,
    })
    setNewTitle('')
    setNewDuration(30)
    setNewFrequency('Quotidien')
    setShowForm(false)
  }

  const completed = habits.filter((h) => h.completedToday).length
  const total = habits.length

  return (
    <div className="flex flex-col gap-3">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
          Suivi des habitudes
        </h2>
        {total > 0 && (
          <span className="text-xs text-muted-foreground">
            {completed}/{total}
          </span>
        )}
      </div>

      {/* Progress bar */}
      {total > 0 && (
        <div className="h-1 bg-muted rounded-full overflow-hidden">
          <div
            className="h-full bg-[#4ecdc4] rounded-full transition-all duration-500"
            style={{ width: `${(completed / total) * 100}%` }}
          />
        </div>
      )}

      {/* Habits list */}
      <div className="flex flex-col gap-1.5">
        {habits.map((habit) => (
          <div
            key={habit.id}
            className="flex items-center gap-2.5 bg-muted/40 hover:bg-muted/70 rounded-lg px-3 py-2.5 group transition-colors border border-border/50"
          >
            <button
              onClick={() => onToggleHabit(habit.id)}
              className="shrink-0 transition-colors"
              style={{ color: habit.completedToday ? habit.color : undefined }}
              aria-label={`${habit.completedToday ? 'Décocher' : 'Cocher'} ${habit.title}`}
            >
              {habit.completedToday ? (
                <CheckCircle2 size={18} style={{ color: habit.color }} />
              ) : (
                <Circle size={18} className="text-muted-foreground" />
              )}
            </button>
            <div
              className="shrink-0 rounded-md p-1"
              style={{ backgroundColor: `${habit.color}20`, color: habit.color }}
            >
              {HABIT_ICONS[habit.icon] || <BookOpen size={14} />}
            </div>
            <div className="flex-1 min-w-0">
              <p
                className={cn(
                  'text-sm leading-tight',
                  habit.completedToday ? 'line-through text-muted-foreground' : 'text-foreground'
                )}
              >
                {habit.title}
              </p>
              <p className="text-[10px] text-muted-foreground">{habit.frequency} · {habit.duration} min</p>
            </div>
            <button
              onClick={() => onDeleteHabit(habit.id)}
              className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive-foreground"
              aria-label={`Supprimer ${habit.title}`}
            >
              <Trash2 size={13} />
            </button>
          </div>
        ))}
        {habits.length === 0 && (
          <p className="text-xs text-muted-foreground text-center py-3">
            Aucune habitude configurée
          </p>
        )}
      </div>

      {/* Add habit */}
      <button
        onClick={() => setShowForm(!showForm)}
        className="text-xs text-primary hover:text-primary/80 transition-colors text-left"
      >
        {showForm ? '— Masquer' : '+ Nouvelle habitude'}
      </button>

      {showForm && (
        <div className="bg-muted/50 border border-border rounded-xl p-3 flex flex-col gap-2">
          <input
            type="text"
            value={newTitle}
            onChange={(e) => setNewTitle(e.target.value)}
            placeholder="Ex: Méditer 10 min"
            className="w-full bg-secondary text-foreground text-sm rounded-lg px-3 py-2 border border-border focus:outline-none focus:ring-1 focus:ring-primary placeholder:text-muted-foreground/50"
          />
          <div className="grid grid-cols-2 gap-2">
            <div className="flex flex-col gap-1">
              <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Durée (min)</label>
              <input
                type="number"
                value={newDuration}
                onChange={(e) => setNewDuration(parseInt(e.target.value) || 15)}
                min={5}
                step={5}
                className="bg-secondary text-foreground text-sm rounded-lg px-3 py-2 border border-border focus:outline-none focus:ring-1 focus:ring-primary"
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Fréquence</label>
              <select
                value={newFrequency}
                onChange={(e) => setNewFrequency(e.target.value)}
                className="bg-secondary text-foreground text-sm rounded-lg px-3 py-2 border border-border focus:outline-none focus:ring-1 focus:ring-primary"
              >
                <option value="Quotidien">Quotidien</option>
                <option value="3x par semaine">3x par semaine</option>
                <option value="5x par semaine">5x par semaine</option>
                <option value="Hebdomadaire">Hebdomadaire</option>
              </select>
            </div>
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Couleur</label>
            <div className="flex gap-2">
              {PRESET_COLORS.map((c) => (
                <button
                  key={c}
                  onClick={() => setNewColor(c)}
                  className={cn(
                    'w-6 h-6 rounded-full border-2 transition-transform hover:scale-110',
                    newColor === c ? 'border-foreground scale-110' : 'border-transparent'
                  )}
                  style={{ backgroundColor: c }}
                  aria-label={`Couleur ${c}`}
                />
              ))}
            </div>
          </div>
          <div className="flex flex-col gap-1">
            <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Icône</label>
            <div className="flex gap-2">
              {Object.entries(HABIT_ICONS).map(([key, icon]) => (
                <button
                  key={key}
                  onClick={() => setNewIcon(key)}
                  className={cn(
                    'p-2 rounded-lg border transition-colors',
                    newIcon === key
                      ? 'border-primary bg-primary/10 text-primary'
                      : 'border-border text-muted-foreground hover:border-primary/50'
                  )}
                >
                  {icon}
                </button>
              ))}
            </div>
          </div>
          <button
            onClick={handleAdd}
            className="w-full bg-[#4ecdc4] text-background text-sm rounded-lg py-2 hover:opacity-90 transition-opacity font-medium"
          >
            Ajouter l&apos;habitude
          </button>
        </div>
      )}
    </div>
  )
}
