'use client'

import { useState } from 'react'
import { Plus, Trash2, Clock, AlertCircle, Pin } from 'lucide-react'
import { Task, Importance, TaskType } from '@/lib/types'
import { TASK_COLORS } from '@/lib/store'
import { cn } from '@/lib/utils'

interface TaskInboxProps {
  tasks: Task[]
  onAddTask: (task: Omit<Task, 'id' | 'status'>) => void
  onDeleteTask: (id: string) => void
}

const importanceLabels: Record<Importance, string> = {
  haute: 'Haute',
  moyenne: 'Moyenne',
  basse: 'Basse',
}

const importanceDotColor: Record<Importance, string> = {
  haute: 'bg-[#ef6c6c]',
  moyenne: 'bg-[#f5a623]',
  basse: 'bg-[#7c6cf5]',
}

export function TaskInbox({ tasks, onAddTask, onDeleteTask }: TaskInboxProps) {
  const [quickInput, setQuickInput] = useState('')
  const [showForm, setShowForm] = useState(false)
  const [newTitle, setNewTitle] = useState('')
  const [newDuration, setNewDuration] = useState(60)
  const [newImportance, setNewImportance] = useState<Importance>('moyenne')
  const [newType, setNewType] = useState<TaskType>('fluide')
  const [newStartTime, setNewStartTime] = useState('')

  const handleQuickAdd = () => {
    if (!quickInput.trim()) return
    // Parse natural language (basic)
    const durationMatch = quickInput.match(/(\d+)\s*heure/i)
    const duration = durationMatch ? parseInt(durationMatch[1]) * 60 : 60
    onAddTask({
      title: quickInput.trim(),
      duration,
      importance: 'moyenne',
      type: 'fluide',
      color: TASK_COLORS.fluide,
    })
    setQuickInput('')
  }

  const handleFormAdd = () => {
    if (!newTitle.trim()) return
    onAddTask({
      title: newTitle.trim(),
      duration: newDuration,
      importance: newImportance,
      type: newType,
      color: newType === 'fixe' ? TASK_COLORS.fixe : TASK_COLORS.fluide,
      startTime: newType === 'fixe' && newStartTime ? newStartTime : undefined,
    })
    setNewTitle('')
    setNewDuration(60)
    setNewImportance('moyenne')
    setNewType('fluide')
    setNewStartTime('')
    setShowForm(false)
  }

  const inboxTasks = tasks.filter((t) => t.status === 'inbox')

  return (
    <div className="flex flex-col gap-3">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
          Boîte de réception
        </h2>
        <span className="text-xs bg-muted text-muted-foreground rounded-full px-2 py-0.5">
          {inboxTasks.length}
        </span>
      </div>

      {/* Quick add input */}
      <div className="flex gap-2">
        <input
          type="text"
          value={quickInput}
          onChange={(e) => setQuickInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleQuickAdd()}
          placeholder="Réviser les maths pendant 2 heures..."
          className="flex-1 bg-muted text-foreground text-sm rounded-lg px-3 py-2 border border-border focus:outline-none focus:ring-1 focus:ring-primary placeholder:text-muted-foreground/50 min-w-0"
        />
        <button
          onClick={handleQuickAdd}
          className="shrink-0 bg-primary text-primary-foreground rounded-lg p-2 hover:opacity-90 transition-opacity"
          aria-label="Ajouter tâche"
        >
          <Plus size={16} />
        </button>
      </div>

      {/* Advanced form toggle */}
      <button
        onClick={() => setShowForm(!showForm)}
        className="text-xs text-primary hover:text-primary/80 transition-colors text-left"
      >
        {showForm ? '— Masquer les options avancées' : '+ Options avancées'}
      </button>

      {/* Advanced form */}
      {showForm && (
        <div className="bg-muted/50 border border-border rounded-xl p-3 flex flex-col gap-2">
          <input
            type="text"
            value={newTitle}
            onChange={(e) => setNewTitle(e.target.value)}
            placeholder="Titre de la tâche"
            className="w-full bg-secondary text-foreground text-sm rounded-lg px-3 py-2 border border-border focus:outline-none focus:ring-1 focus:ring-primary placeholder:text-muted-foreground/50"
          />
          <div className="grid grid-cols-2 gap-2">
            <div className="flex flex-col gap-1">
              <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Durée (min)</label>
              <input
                type="number"
                value={newDuration}
                onChange={(e) => setNewDuration(parseInt(e.target.value) || 30)}
                min={15}
                step={15}
                className="bg-secondary text-foreground text-sm rounded-lg px-3 py-2 border border-border focus:outline-none focus:ring-1 focus:ring-primary"
              />
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Importance</label>
              <select
                value={newImportance}
                onChange={(e) => setNewImportance(e.target.value as Importance)}
                className="bg-secondary text-foreground text-sm rounded-lg px-3 py-2 border border-border focus:outline-none focus:ring-1 focus:ring-primary"
              >
                <option value="haute">Haute</option>
                <option value="moyenne">Moyenne</option>
                <option value="basse">Basse</option>
              </select>
            </div>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setNewType('fluide')}
              className={cn(
                'flex-1 text-xs py-2 rounded-lg border transition-colors',
                newType === 'fluide'
                  ? 'bg-primary/20 border-primary text-primary'
                  : 'border-border text-muted-foreground hover:border-primary/50'
              )}
            >
              Tâche Fluide
            </button>
            <button
              onClick={() => setNewType('fixe')}
              className={cn(
                'flex-1 text-xs py-2 rounded-lg border transition-colors',
                newType === 'fixe'
                  ? 'bg-[#ef6c6c]/20 border-[#ef6c6c] text-[#ef6c6c]'
                  : 'border-border text-muted-foreground hover:border-[#ef6c6c]/50'
              )}
            >
              Événement Fixe
            </button>
          </div>
          {newType === 'fixe' && (
            <div className="flex flex-col gap-1">
              <label className="text-[10px] uppercase tracking-wider text-muted-foreground">Heure de début</label>
              <input
                type="time"
                value={newStartTime}
                onChange={(e) => setNewStartTime(e.target.value)}
                className="bg-secondary text-foreground text-sm rounded-lg px-3 py-2 border border-border focus:outline-none focus:ring-1 focus:ring-primary"
              />
            </div>
          )}
          <button
            onClick={handleFormAdd}
            className="w-full bg-primary text-primary-foreground text-sm rounded-lg py-2 hover:opacity-90 transition-opacity font-medium"
          >
            Ajouter à l&apos;inbox
          </button>
        </div>
      )}

      {/* Task list */}
      <div className="flex flex-col gap-1.5 max-h-64 overflow-y-auto pr-1">
        {inboxTasks.length === 0 && (
          <p className="text-xs text-muted-foreground text-center py-4">
            Aucune tâche dans l&apos;inbox
          </p>
        )}
        {inboxTasks.map((task) => (
          <div
            key={task.id}
            className="flex items-start gap-2 bg-muted/40 hover:bg-muted/70 rounded-lg px-3 py-2.5 group transition-colors border border-border/50"
          >
            <div
              className="w-2.5 h-2.5 rounded-full shrink-0 mt-0.5"
              style={{ backgroundColor: task.color }}
            />
            <div className="flex-1 min-w-0">
              <p className="text-sm text-foreground leading-tight line-clamp-1">{task.title}</p>
              <div className="flex items-center gap-2 mt-0.5">
                <span className="flex items-center gap-0.5 text-[10px] text-muted-foreground">
                  <Clock size={9} />
                  {task.duration >= 60
                    ? `${task.duration / 60}h${task.duration % 60 > 0 ? task.duration % 60 + 'min' : ''}`
                    : `${task.duration}min`}
                </span>
                <span className={cn('flex items-center gap-0.5 text-[10px] text-muted-foreground')}>
                  <span className={cn('inline-block w-1.5 h-1.5 rounded-full', importanceDotColor[task.importance])} />
                  {importanceLabels[task.importance]}
                </span>
                {task.type === 'fixe' && (
                  <span className="flex items-center gap-0.5 text-[10px] text-[#ef6c6c]">
                    <Pin size={9} />
                    Fixe{task.startTime ? ` · ${task.startTime}` : ''}
                  </span>
                )}
              </div>
            </div>
            <button
              onClick={() => onDeleteTask(task.id)}
              className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-destructive-foreground"
              aria-label={`Supprimer ${task.title}`}
            >
              <Trash2 size={13} />
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}
