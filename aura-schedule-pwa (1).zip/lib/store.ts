import { Task, CalendarBlock, Habit, SleepConfig, DayData } from './types'

export const TASK_COLORS = {
  fixe: '#ef6c6c',
  fluide: '#7c6cf5',
  habit: '#4ecdc4',
  sommeil: '#2d2d4a',
  tampon: '#252535',
}

export const IMPORTANCE_COLORS: Record<string, string> = {
  haute: '#ef6c6c',
  moyenne: '#f5a623',
  basse: '#7c6cf5',
}

export const MOIS_FR = [
  'janvier', 'février', 'mars', 'avril', 'mai', 'juin',
  'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre',
]

export const JOURS_FR = ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam']
export const JOURS_FR_FULL = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi']

export const initialSleepConfig: SleepConfig = {
  bedtime: '23:00',
  wakeup: '07:00',
}

export const initialTasks: Task[] = [
  {
    id: 't1',
    title: 'Cours de mathématiques',
    duration: 90,
    importance: 'haute',
    type: 'fixe',
    status: 'inbox',
    color: TASK_COLORS.fixe,
    startTime: '10:00',
  },
  {
    id: 't2',
    title: 'Réunion d\'équipe projet',
    duration: 60,
    importance: 'haute',
    type: 'fixe',
    status: 'inbox',
    color: TASK_COLORS.fixe,
    startTime: '14:00',
  },
  {
    id: 't3',
    title: 'Réviser les maths pendant 2 heures',
    duration: 120,
    importance: 'haute',
    type: 'fluide',
    status: 'inbox',
    color: TASK_COLORS.fluide,
  },
  {
    id: 't4',
    title: 'Rédiger rapport de stage',
    duration: 90,
    importance: 'moyenne',
    type: 'fluide',
    status: 'inbox',
    color: TASK_COLORS.fluide,
  },
  {
    id: 't5',
    title: 'Répondre aux e-mails',
    duration: 30,
    importance: 'basse',
    type: 'fluide',
    status: 'inbox',
    color: TASK_COLORS.fluide,
  },
]

export const initialHabits: Habit[] = [
  {
    id: 'h1',
    title: 'Lire 30 min',
    duration: 30,
    frequency: 'Quotidien',
    color: '#4ecdc4',
    completedToday: false,
    icon: 'BookOpen',
  },
  {
    id: 'h2',
    title: 'Sport / Cardio',
    duration: 45,
    frequency: '3x par semaine',
    color: '#f5a623',
    completedToday: false,
    icon: 'Dumbbell',
  },
]

// === Date Utilities ===

export function formatDateKey(date: Date): string {
  return date.toISOString().split('T')[0]
}

export function parseDateKey(key: string): Date {
  return new Date(key + 'T00:00:00')
}

export function getToday(): string {
  return formatDateKey(new Date())
}

export function addDays(dateKey: string, days: number): string {
  const d = parseDateKey(dateKey)
  d.setDate(d.getDate() + days)
  return formatDateKey(d)
}

export function isSameDay(a: string, b: string): boolean {
  return a === b
}

export function isToday(dateKey: string): boolean {
  return dateKey === getToday()
}

export function formatDateLabel(dateKey: string): string {
  const d = parseDateKey(dateKey)
  const jour = JOURS_FR_FULL[d.getDay()]
  const date = d.getDate()
  const mois = MOIS_FR[d.getMonth()]
  const year = d.getFullYear()
  return `${jour} ${date} ${mois} ${year}`
}

export function formatShortDateLabel(dateKey: string): string {
  const d = parseDateKey(dateKey)
  const jour = JOURS_FR[d.getDay()]
  const date = d.getDate()
  const mois = MOIS_FR[d.getMonth()]
  return `${jour} ${date} ${mois}`
}

export function getWeekDays(dateKey: string): string[] {
  const d = parseDateKey(dateKey)
  const dayOfWeek = d.getDay()
  const mondayOffset = dayOfWeek === 0 ? -6 : 1 - dayOfWeek
  const monday = new Date(d)
  monday.setDate(d.getDate() + mondayOffset)
  
  const days: string[] = []
  for (let i = 0; i < 7; i++) {
    const day = new Date(monday)
    day.setDate(monday.getDate() + i)
    days.push(formatDateKey(day))
  }
  return days
}

export function getMonthDays(dateKey: string): string[] {
  const d = parseDateKey(dateKey)
  const year = d.getFullYear()
  const month = d.getMonth()
  const firstDay = new Date(year, month, 1)
  const lastDay = new Date(year, month + 1, 0)
  
  const days: string[] = []
  for (let i = 1; i <= lastDay.getDate(); i++) {
    days.push(formatDateKey(new Date(year, month, i)))
  }
  return days
}

// === Time Utilities ===

export function timeToMinutes(time: string): number {
  const [h, m] = time.split(':').map(Number)
  return h * 60 + m
}

export function minutesToTime(minutes: number): string {
  const h = Math.floor(minutes / 60) % 24
  const m = minutes % 60
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`
}

// === Schedule Generation ===

export function generateDaySchedule(
  tasks: Task[],
  habits: Habit[],
  sleepConfig: SleepConfig,
  dateKey: string
): CalendarBlock[] {
  const blocks: CalendarBlock[] = []
  const wakeMinutes = timeToMinutes(sleepConfig.wakeup)
  const bedMinutes = timeToMinutes(sleepConfig.bedtime)

  // Sleep blocks
  blocks.push({
    id: `sleep-night-${dateKey}`,
    taskId: 'sleep',
    title: 'Sommeil',
    startTime: '00:00',
    endTime: sleepConfig.wakeup,
    color: TASK_COLORS.sommeil,
    type: 'sommeil',
    completed: false,
  })

  blocks.push({
    id: `sleep-evening-${dateKey}`,
    taskId: 'sleep',
    title: 'Sommeil',
    startTime: sleepConfig.bedtime,
    endTime: '24:00',
    color: TASK_COLORS.sommeil,
    type: 'sommeil',
    completed: false,
  })

  // Fixed tasks
  const fixedTasks = tasks.filter((t) => t.type === 'fixe' && t.startTime)
  const allOccupied: { start: number; end: number }[] = []

  fixedTasks.forEach((task) => {
    const start = timeToMinutes(task.startTime!)
    const end = start + task.duration
    blocks.push({
      id: `block-${task.id}-${dateKey}`,
      taskId: task.id,
      title: task.title,
      startTime: task.startTime!,
      endTime: minutesToTime(end),
      color: TASK_COLORS.fixe,
      type: 'fixe',
      importance: task.importance,
      completed: false,
    })
    allOccupied.push({ start, end })
  })

  // Add sleep as occupied
  allOccupied.push({ start: 0, end: wakeMinutes })
  allOccupied.push({ start: bedMinutes, end: 1440 })
  allOccupied.sort((a, b) => a.start - b.start)

  const getFreeSlots = () => {
    const slots: { start: number; end: number }[] = []
    let cursor = wakeMinutes
    for (const block of allOccupied.sort((a, b) => a.start - b.start)) {
      if (block.start > cursor) {
        slots.push({ start: cursor, end: block.start })
      }
      if (block.end > cursor) cursor = block.end
    }
    if (cursor < bedMinutes) {
      slots.push({ start: cursor, end: bedMinutes })
    }
    return slots
  }

  // Fluid tasks (priority sorted)
  const fluidTasks = [
    ...tasks.filter((t) => t.type === 'fluide' && t.importance === 'haute'),
    ...tasks.filter((t) => t.type === 'fluide' && t.importance === 'moyenne'),
    ...tasks.filter((t) => t.type === 'fluide' && t.importance === 'basse'),
  ]

  for (const task of fluidTasks) {
    const slots = getFreeSlots()
    for (const slot of slots) {
      if (slot.end - slot.start >= task.duration + 15) {
        const start = slot.start
        const end = start + task.duration
        blocks.push({
          id: `block-${task.id}-${dateKey}`,
          taskId: task.id,
          title: task.title,
          startTime: minutesToTime(start),
          endTime: minutesToTime(end),
          color: TASK_COLORS.fluide,
          type: 'fluide',
          importance: task.importance,
          completed: false,
        })
        blocks.push({
          id: `buffer-${task.id}-${dateKey}`,
          taskId: `buffer-${task.id}`,
          title: 'Pause',
          startTime: minutesToTime(end),
          endTime: minutesToTime(end + 15),
          color: TASK_COLORS.tampon,
          type: 'tampon',
          completed: false,
        })
        allOccupied.push({ start, end: end + 15 })
        allOccupied.sort((a, b) => a.start - b.start)
        break
      }
    }
  }

  // Habits
  for (const habit of habits) {
    const slots = getFreeSlots()
    for (const slot of slots) {
      if (slot.end - slot.start >= habit.duration) {
        const start = slot.end - habit.duration
        blocks.push({
          id: `block-habit-${habit.id}-${dateKey}`,
          taskId: habit.id,
          title: habit.title,
          startTime: minutesToTime(start),
          endTime: minutesToTime(start + habit.duration),
          color: habit.color,
          type: 'habit',
          completed: false,
        })
        allOccupied.push({ start, end: start + habit.duration })
        allOccupied.sort((a, b) => a.start - b.start)
        break
      }
    }
  }

  return blocks.sort((a, b) => timeToMinutes(a.startTime) - timeToMinutes(b.startTime))
}

// Recalculate from current time
export function recalculateFromNow(
  existingBlocks: CalendarBlock[],
  tasks: Task[],
  habits: Habit[],
  sleepConfig: SleepConfig,
  dateKey: string
): CalendarBlock[] {
  const now = new Date()
  const currentMinutes = now.getHours() * 60 + now.getMinutes()
  const today = getToday()

  // If not today, regenerate fully
  if (dateKey !== today) {
    return generateDaySchedule(tasks, habits, sleepConfig, dateKey)
  }

  // Keep past blocks and sleep
  const keptBlocks = existingBlocks.filter((b) => {
    const endMin = b.endTime === '24:00' ? 1440 : timeToMinutes(b.endTime)
    return endMin <= currentMinutes || b.type === 'sommeil'
  })

  const scheduledTaskIds = new Set(keptBlocks.map((b) => b.taskId))
  const remainingFluid = tasks.filter(
    (t) => t.type === 'fluide' && !scheduledTaskIds.has(t.id)
  )
  const remainingHabits = habits.filter(
    (h) => !scheduledTaskIds.has(h.id)
  )

  // Keep future fixed
  const futureFixed = existingBlocks.filter((b) => {
    const startMin = timeToMinutes(b.startTime)
    return startMin >= currentMinutes && b.type === 'fixe'
  })

  const base = [...keptBlocks, ...futureFixed]
  const bedMinutes = timeToMinutes(sleepConfig.bedtime)

  const allOccupied = base
    .filter((b) => b.type !== 'tampon')
    .map((b) => ({
      start: timeToMinutes(b.startTime),
      end: b.endTime === '24:00' ? 1440 : timeToMinutes(b.endTime),
    }))
    .sort((a, b) => a.start - b.start)

  const getFreeSlots = () => {
    const slots: { start: number; end: number }[] = []
    let cursor = currentMinutes
    for (const block of allOccupied.sort((a, b) => a.start - b.start)) {
      if (block.start > cursor) {
        slots.push({ start: cursor, end: block.start })
      }
      if (block.end > cursor) cursor = block.end
    }
    if (cursor < bedMinutes) {
      slots.push({ start: cursor, end: bedMinutes })
    }
    return slots
  }

  const newBlocks: CalendarBlock[] = []

  const fluidSorted = [
    ...remainingFluid.filter((t) => t.importance === 'haute'),
    ...remainingFluid.filter((t) => t.importance === 'moyenne'),
    ...remainingFluid.filter((t) => t.importance === 'basse'),
  ]

  for (const task of fluidSorted) {
    const slots = getFreeSlots()
    for (const slot of slots) {
      if (slot.end - slot.start >= task.duration + 15) {
        const start = slot.start
        const end = start + task.duration
        newBlocks.push({
          id: `block-${task.id}-${dateKey}-r`,
          taskId: task.id,
          title: task.title,
          startTime: minutesToTime(start),
          endTime: minutesToTime(end),
          color: TASK_COLORS.fluide,
          type: 'fluide',
          importance: task.importance,
          completed: false,
        })
        newBlocks.push({
          id: `buffer-${task.id}-${dateKey}-r`,
          taskId: `buffer-${task.id}-r`,
          title: 'Pause',
          startTime: minutesToTime(end),
          endTime: minutesToTime(end + 15),
          color: TASK_COLORS.tampon,
          type: 'tampon',
          completed: false,
        })
        allOccupied.push({ start, end: end + 15 })
        allOccupied.sort((a, b) => a.start - b.start)
        break
      }
    }
  }

  for (const habit of remainingHabits) {
    const slots = getFreeSlots()
    for (const slot of slots) {
      if (slot.end - slot.start >= habit.duration) {
        const start = slot.end - habit.duration
        newBlocks.push({
          id: `block-habit-${habit.id}-${dateKey}-r`,
          taskId: habit.id,
          title: habit.title,
          startTime: minutesToTime(start),
          endTime: minutesToTime(start + habit.duration),
          color: habit.color,
          type: 'habit',
          completed: false,
        })
        allOccupied.push({ start, end: start + habit.duration })
        allOccupied.sort((a, b) => a.start - b.start)
        break
      }
    }
  }

  return [...base, ...newBlocks].sort(
    (a, b) => timeToMinutes(a.startTime) - timeToMinutes(b.startTime)
  )
}

// === Local Storage ===

const STORAGE_KEY = 'aura-schedule-v2'

export interface StoredData {
  tasks: Task[]
  habits: Habit[]
  sleepConfig: SleepConfig
  dayDataByDate: Record<string, DayData>
}

export function loadFromStorage(): StoredData | null {
  if (typeof window === 'undefined') return null
  try {
    const saved = localStorage.getItem(STORAGE_KEY)
    if (saved) {
      return JSON.parse(saved)
    }
  } catch {
    // ignore
  }
  return null
}

export function saveToStorage(data: StoredData): void {
  if (typeof window === 'undefined') return
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data))
  } catch {
    // ignore
  }
}

export function clearOldData(data: StoredData, keepDays = 30): StoredData {
  const today = new Date()
  const cutoff = new Date(today)
  cutoff.setDate(today.getDate() - keepDays)
  const cutoffKey = formatDateKey(cutoff)
  
  const filtered: Record<string, DayData> = {}
  for (const [key, value] of Object.entries(data.dayDataByDate)) {
    if (key >= cutoffKey) {
      filtered[key] = value
    }
  }
  
  return { ...data, dayDataByDate: filtered }
}
