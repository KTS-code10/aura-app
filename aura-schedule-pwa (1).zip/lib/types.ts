export type Importance = 'haute' | 'moyenne' | 'basse'
export type TaskType = 'fixe' | 'fluide'
export type TaskStatus = 'inbox' | 'scheduled' | 'completed'

export interface Task {
  id: string
  title: string
  duration: number // in minutes
  importance: Importance
  type: TaskType
  status: TaskStatus
  color?: string
  startTime?: string // "HH:MM"
  notes?: string
}

export interface CalendarBlock {
  id: string
  taskId: string
  title: string
  startTime: string // "HH:MM"
  endTime: string   // "HH:MM"
  color: string
  type: 'fixe' | 'fluide' | 'habit' | 'sommeil' | 'tampon'
  importance?: Importance
  completed: boolean
}

export interface Habit {
  id: string
  title: string
  duration: number // in minutes
  frequency: string // e.g. "Quotidien", "3x par semaine"
  color: string
  completedToday: boolean
  icon: string
}

export interface SleepConfig {
  bedtime: string   // "HH:MM"
  wakeup: string    // "HH:MM"
}

export interface DayData {
  blocks: CalendarBlock[]
  habitCompletions: Record<string, boolean>
}

export interface AppState {
  tasks: Task[]
  dayDataByDate: Record<string, DayData> // keyed by YYYY-MM-DD
  habits: Habit[]
  sleepConfig: SleepConfig
  selectedDate: string // YYYY-MM-DD
}
