'use client'

import { useState, useEffect, useCallback } from 'react'
import { Sparkles, RefreshCw, Menu, X, Zap, Wifi, WifiOff } from 'lucide-react'
import { Task, CalendarBlock, Habit, SleepConfig, DayData } from '@/lib/types'
import {
  initialTasks,
  initialHabits,
  initialSleepConfig,
  generateDaySchedule,
  recalculateFromNow,
  getToday,
  isToday,
  loadFromStorage,
  saveToStorage,
  clearOldData,
  StoredData,
} from '@/lib/store'
import { TaskInbox } from '@/components/aura/TaskInbox'
import { HabitTracker } from '@/components/aura/HabitTracker'
import { SleepSettings } from '@/components/aura/SleepSettings'
import { CalendarTimeline } from '@/components/aura/CalendarTimeline'
import { EditBlockModal } from '@/components/aura/EditBlockModal'
import { DateNavigator } from '@/components/aura/DateNavigator'
import { cn } from '@/lib/utils'

function generateId() {
  return Math.random().toString(36).slice(2, 10)
}

export default function AuraSchedulePage() {
  const [tasks, setTasks] = useState<Task[]>(initialTasks)
  const [habits, setHabits] = useState<Habit[]>(initialHabits)
  const [sleepConfig, setSleepConfig] = useState<SleepConfig>(initialSleepConfig)
  const [dayDataByDate, setDayDataByDate] = useState<Record<string, DayData>>({})
  const [selectedDate, setSelectedDate] = useState(getToday)

  const [isGenerating, setIsGenerating] = useState(false)
  const [isRecalculating, setIsRecalculating] = useState(false)
  const [aiMessage, setAiMessage] = useState('')
  const [editingBlock, setEditingBlock] = useState<CalendarBlock | null>(null)
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [settingsTab, setSettingsTab] = useState<'inbox' | 'habits' | 'sleep'>('inbox')
  const [isOnline, setIsOnline] = useState(true)
  const [isHydrated, setIsHydrated] = useState(false)

  // Current day data
  const currentDayData = dayDataByDate[selectedDate] || { blocks: [], habitCompletions: {} }
  const blocks = currentDayData.blocks

  // Register service worker
  useEffect(() => {
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('/sw.js').catch(() => {
        // SW registration failed, app still works
      })
    }

    // Online/offline detection
    const updateOnlineStatus = () => setIsOnline(navigator.onLine)
    window.addEventListener('online', updateOnlineStatus)
    window.addEventListener('offline', updateOnlineStatus)
    setIsOnline(navigator.onLine)

    return () => {
      window.removeEventListener('online', updateOnlineStatus)
      window.removeEventListener('offline', updateOnlineStatus)
    }
  }, [])

  // Load from localStorage
  useEffect(() => {
    const saved = loadFromStorage()
    if (saved) {
      const cleaned = clearOldData(saved)
      setTasks(cleaned.tasks)
      setHabits(cleaned.habits)
      setSleepConfig(cleaned.sleepConfig)
      setDayDataByDate(cleaned.dayDataByDate)
    }
    setIsHydrated(true)
  }, [])

  // Save to localStorage
  useEffect(() => {
    if (!isHydrated) return
    const data: StoredData = { tasks, habits, sleepConfig, dayDataByDate }
    saveToStorage(data)
  }, [tasks, habits, sleepConfig, dayDataByDate, isHydrated])

  // Update day data helper
  const updateDayData = useCallback((date: string, blocks: CalendarBlock[]) => {
    setDayDataByDate((prev) => ({
      ...prev,
      [date]: {
        ...prev[date],
        blocks,
        habitCompletions: prev[date]?.habitCompletions || {},
      },
    }))
  }, [])

  // Generate schedule for selected date
  const handleGenerateDay = useCallback(() => {
    setIsGenerating(true)
    setAiMessage("L'IA organise votre journée...")
    setTimeout(() => {
      setAiMessage('Optimisation des créneaux horaires...')
      setTimeout(() => {
        const generated = generateDaySchedule(tasks, habits, sleepConfig, selectedDate)
        updateDayData(selectedDate, generated)
        setIsGenerating(false)
        setAiMessage('')
      }, 800)
    }, 700)
  }, [tasks, habits, sleepConfig, selectedDate, updateDayData])

  // Recalculate from now
  const handleRecalculate = useCallback(() => {
    setIsRecalculating(true)
    setAiMessage('Reconfiguration du planning en cours...')
    setTimeout(() => {
      setAiMessage('Ajout des pauses de 15 minutes...')
      setTimeout(() => {
        const recalculated = recalculateFromNow(blocks, tasks, habits, sleepConfig, selectedDate)
        updateDayData(selectedDate, recalculated)
        setIsRecalculating(false)
        setAiMessage('')
      }, 700)
    }, 800)
  }, [blocks, tasks, habits, sleepConfig, selectedDate, updateDayData])

  // Task management
  const handleAddTask = (task: Omit<Task, 'id' | 'status'>) => {
    setTasks((prev) => [...prev, { ...task, id: generateId(), status: 'inbox' }])
  }

  const handleDeleteTask = (id: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== id))
    // Remove from all days
    setDayDataByDate((prev) => {
      const updated = { ...prev }
      for (const date of Object.keys(updated)) {
        updated[date] = {
          ...updated[date],
          blocks: updated[date].blocks.filter((b) => b.taskId !== id),
        }
      }
      return updated
    })
  }

  // Habit management
  const handleToggleHabit = (id: string) => {
    setHabits((prev) =>
      prev.map((h) => (h.id === id ? { ...h, completedToday: !h.completedToday } : h))
    )
    // Toggle in current day blocks
    setDayDataByDate((prev) => ({
      ...prev,
      [selectedDate]: {
        ...prev[selectedDate],
        blocks: prev[selectedDate]?.blocks.map((b) =>
          b.taskId === id ? { ...b, completed: !b.completed } : b
        ) || [],
        habitCompletions: {
          ...prev[selectedDate]?.habitCompletions,
          [id]: !prev[selectedDate]?.habitCompletions?.[id],
        },
      },
    }))
  }

  const handleAddHabit = (habit: Omit<Habit, 'id' | 'completedToday'>) => {
    setHabits((prev) => [...prev, { ...habit, id: generateId(), completedToday: false }])
  }

  const handleDeleteHabit = (id: string) => {
    setHabits((prev) => prev.filter((h) => h.id !== id))
    setDayDataByDate((prev) => {
      const updated = { ...prev }
      for (const date of Object.keys(updated)) {
        updated[date] = {
          ...updated[date],
          blocks: updated[date].blocks.filter((b) => b.taskId !== id),
        }
      }
      return updated
    })
  }

  // Block management
  const handleSaveBlock = (updated: CalendarBlock) => {
    setDayDataByDate((prev) => ({
      ...prev,
      [selectedDate]: {
        ...prev[selectedDate],
        blocks: prev[selectedDate]?.blocks.map((b) => (b.id === updated.id ? updated : b)) || [],
      },
    }))
    setEditingBlock(null)
  }

  const handleDeleteBlock = (id: string) => {
    setDayDataByDate((prev) => ({
      ...prev,
      [selectedDate]: {
        ...prev[selectedDate],
        blocks: prev[selectedDate]?.blocks.filter((b) => b.id !== id) || [],
      },
    }))
    setEditingBlock(null)
  }

  const handleToggleBlock = (id: string) => {
    setDayDataByDate((prev) => ({
      ...prev,
      [selectedDate]: {
        ...prev[selectedDate],
        blocks: prev[selectedDate]?.blocks.map((b) =>
          b.id === id ? { ...b, completed: !b.completed } : b
        ) || [],
      },
    }))
  }

  // Progress stats
  const actionableBlocks = blocks.filter((b) => b.type !== 'sommeil' && b.type !== 'tampon')
  const completedCount = actionableBlocks.filter((b) => b.completed).length
  const totalCount = actionableBlocks.length
  const progressPercent = totalCount > 0 ? (completedCount / totalCount) * 100 : 0

  if (!isHydrated) {
    return (
      <div className="flex items-center justify-center h-screen bg-background">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/20 border border-primary/30 flex items-center justify-center animate-pulse">
            <Zap size={20} className="text-primary" />
          </div>
          <p className="text-sm text-muted-foreground">Chargement...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col h-screen bg-background overflow-hidden">
      {/* Top bar */}
      <header className="flex items-center justify-between px-4 py-3 border-b border-border shrink-0 bg-card/50 backdrop-blur-sm z-10">
        <div className="flex items-center gap-3">
          <button
            className="md:hidden p-1.5 rounded-lg hover:bg-muted transition-colors text-muted-foreground"
            onClick={() => setSidebarOpen(!sidebarOpen)}
            aria-label={sidebarOpen ? 'Fermer le menu' : 'Ouvrir le menu'}
          >
            {sidebarOpen ? <X size={18} /> : <Menu size={18} />}
          </button>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-primary/20 border border-primary/30 flex items-center justify-center">
              <Zap size={14} className="text-primary" />
            </div>
            <span className="font-semibold text-sm tracking-tight text-foreground">
              Aura<span className="text-primary">Schedule</span>
            </span>
          </div>
          {/* Online status */}
          <div className={cn(
            'flex items-center gap-1 px-2 py-1 rounded-full text-[10px]',
            isOnline ? 'bg-green-500/10 text-green-400' : 'bg-yellow-500/10 text-yellow-400'
          )}>
            {isOnline ? <Wifi size={10} /> : <WifiOff size={10} />}
            <span className="hidden sm:inline">{isOnline ? 'En ligne' : 'Hors ligne'}</span>
          </div>
        </div>

        {/* Progress + AI buttons */}
        <div className="flex items-center gap-2">
          {totalCount > 0 && (
            <div className="hidden sm:flex items-center gap-2 mr-1">
              <div className="h-1.5 w-20 bg-muted rounded-full overflow-hidden">
                <div
                  className="h-full bg-primary rounded-full transition-all duration-700"
                  style={{ width: `${progressPercent}%` }}
                />
              </div>
              <span className="text-[10px] text-muted-foreground tabular-nums">
                {completedCount}/{totalCount}
              </span>
            </div>
          )}

          <button
            onClick={handleGenerateDay}
            disabled={isGenerating || isRecalculating}
            className={cn(
              'flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-medium transition-all',
              'bg-primary text-primary-foreground hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed'
            )}
          >
            {isGenerating ? (
              <RefreshCw size={13} className="animate-spin" />
            ) : (
              <Sparkles size={13} />
            )}
            <span className="hidden sm:inline">Générer (IA)</span>
            <span className="sm:hidden">IA</span>
          </button>

          {isToday(selectedDate) && (
            <button
              onClick={handleRecalculate}
              disabled={isGenerating || isRecalculating || blocks.length === 0}
              className={cn(
                'flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-medium border transition-all',
                'border-[#4ecdc4]/50 text-[#4ecdc4] hover:bg-[#4ecdc4]/10',
                'disabled:opacity-40 disabled:cursor-not-allowed'
              )}
            >
              {isRecalculating ? (
                <RefreshCw size={13} className="animate-spin" />
              ) : (
                <RefreshCw size={13} />
              )}
              <span className="hidden sm:inline">Recalculer</span>
            </button>
          )}
        </div>
      </header>

      {/* AI Loading overlay */}
      {(isGenerating || isRecalculating) && aiMessage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/70 backdrop-blur-sm pointer-events-none">
          <div className="bg-card border border-border rounded-2xl px-8 py-6 flex flex-col items-center gap-3 shadow-2xl max-w-xs w-full mx-4">
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-primary/20 border border-primary/30 flex items-center justify-center">
                <Sparkles size={18} className="text-primary animate-pulse" />
              </div>
              <div>
                <p className="text-sm font-semibold text-foreground">AuraSchedule IA</p>
                <p className="text-[10px] text-muted-foreground">Planificateur intelligent</p>
              </div>
            </div>
            <p className="text-sm text-muted-foreground text-center leading-relaxed">
              {aiMessage}
            </p>
            <div className="flex gap-1.5">
              {[0, 1, 2].map((i) => (
                <div
                  key={i}
                  className="w-2 h-2 rounded-full bg-primary animate-bounce"
                  style={{ animationDelay: `${i * 0.18}s` }}
                />
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Main layout */}
      <div className="flex flex-1 overflow-hidden relative">
        {/* Mobile overlay */}
        {sidebarOpen && (
          <div
            className="fixed inset-0 bg-background/80 z-20 md:hidden"
            onClick={() => setSidebarOpen(false)}
            aria-hidden="true"
          />
        )}

        {/* Sidebar */}
        <aside
          className={cn(
            'w-72 shrink-0 border-r border-border bg-card flex flex-col overflow-hidden',
            'fixed md:relative z-30 top-[57px] bottom-0 left-0',
            'transition-transform duration-300 ease-in-out',
            sidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
          )}
        >
          <nav className="flex border-b border-border shrink-0" aria-label="Sections du panneau">
            {(
              [
                { key: 'inbox', label: 'Inbox' },
                { key: 'habits', label: 'Habitudes' },
                { key: 'sleep', label: 'Sommeil' },
              ] as const
            ).map(({ key, label }) => (
              <button
                key={key}
                onClick={() => setSettingsTab(key)}
                className={cn(
                  'flex-1 py-3 text-[11px] font-medium transition-colors border-b-2 -mb-px',
                  settingsTab === key
                    ? 'border-primary text-primary'
                    : 'border-transparent text-muted-foreground hover:text-foreground'
                )}
                aria-selected={settingsTab === key}
                role="tab"
              >
                {label}
              </button>
            ))}
          </nav>

          <div className="flex-1 overflow-y-auto p-4" role="tabpanel">
            {settingsTab === 'inbox' && (
              <TaskInbox
                tasks={tasks}
                onAddTask={handleAddTask}
                onDeleteTask={handleDeleteTask}
              />
            )}
            {settingsTab === 'habits' && (
              <HabitTracker
                habits={habits}
                onToggleHabit={handleToggleHabit}
                onAddHabit={handleAddHabit}
                onDeleteHabit={handleDeleteHabit}
              />
            )}
            {settingsTab === 'sleep' && (
              <SleepSettings config={sleepConfig} onChange={setSleepConfig} />
            )}
          </div>
        </aside>

        {/* Calendar panel */}
        <main className="flex-1 flex flex-col overflow-hidden min-w-0">
          {/* Date navigator */}
          <div className="px-4 py-3 border-b border-border shrink-0 bg-card/30 relative">
            <DateNavigator
              selectedDate={selectedDate}
              onDateChange={setSelectedDate}
              dayDataByDate={dayDataByDate}
            />
          </div>

          {/* Legend */}
          <div className="flex items-center justify-between px-4 py-2 border-b border-border shrink-0 bg-card/20">
            {blocks.length === 0 ? (
              <p className="text-[11px] text-muted-foreground">
                Cliquez sur{' '}
                <span className="text-primary font-medium">&ldquo;Générer (IA)&rdquo;</span>{' '}
                pour remplir votre calendrier
              </p>
            ) : (
              <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
                <span className="flex items-center gap-1">
                  <span className="inline-block w-2 h-2 rounded-sm bg-[#ef6c6c]" />
                  Fixe
                </span>
                <span className="flex items-center gap-1">
                  <span className="inline-block w-2 h-2 rounded-sm bg-[#7c6cf5]" />
                  Fluide
                </span>
                <span className="flex items-center gap-1">
                  <span className="inline-block w-2 h-2 rounded-sm bg-[#4ecdc4]" />
                  Habitude
                </span>
              </div>
            )}
            {!isToday(selectedDate) && blocks.length > 0 && (
              <span className="text-[10px] text-yellow-400/80">
                Vue du {selectedDate}
              </span>
            )}
          </div>

          {/* Timeline */}
          <CalendarTimeline
            blocks={blocks}
            onEditBlock={setEditingBlock}
            onDeleteBlock={handleDeleteBlock}
            onToggleBlock={handleToggleBlock}
            selectedDate={selectedDate}
          />
        </main>
      </div>

      {/* Edit modal */}
      <EditBlockModal
        block={editingBlock}
        onClose={() => setEditingBlock(null)}
        onSave={handleSaveBlock}
        onDelete={handleDeleteBlock}
      />
    </div>
  )
}
